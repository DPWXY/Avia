//
//  FlightGroup.swift
//  avia_copilot_ios
//
//  Created by Rana Taki on 2/7/25.
//

import UIKit

enum GroupType {
    case publicgroup
    case privategroup
    case joinable
    
    var buttonTitle: String {
        switch self {
        case .publicgroup: return "Public Group"
        case .privategroup: return "Private Group"
        case .joinable: return "Join"
        }
    }
}

struct FlightGroup {
    let id: String
    let name: String
    let profileImage: UIImage?
    let memberCount: Int
    let groupType: GroupType
    
    static func sampleGroups() -> [FlightGroup] {
        return [
            FlightGroup(id: "1", name: "Sky Warriors", profileImage: UIImage(named: "group1"), memberCount: 25, groupType: .joinable),
            FlightGroup(id: "2", name: "Elite Pilots", profileImage: UIImage(named: "group1"), memberCount: 50, groupType: .publicgroup),
            FlightGroup(id: "3", name: "Aviation Club", profileImage: UIImage(named: "group1"), memberCount: 30, groupType: .privategroup),
            // Add more sample groups as needed
        ]
    }
}

//
//  ProfileVC.swift
//  avia_copilot_ios
//
//  Created by Rana Taki on 2/4/25.
//

import UIKit

class ProfileVC: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var scrollView: UIScrollView!
    
    // Stack Views
    @IBOutlet weak var postsStackView: UIStackView!
    @IBOutlet weak var groupsStackView: UIStackView!
    
    private var posts: [PilotPost] = []
    private var groups: [FlightGroup] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupProfileImage()
        setupUI()
        setupScrollView()
        loadPosts()
        loadGroups()
    }
    
    // MARK: Profile Header View
    private func setupProfileImage() {
        // Make image view circular
        profileImageView.layer.cornerRadius = profileImageView.frame.height / 2
        profileImageView.clipsToBounds = true
        
        // Add border
        profileImageView.layer.borderWidth = 2
        profileImageView.layer.borderColor = UIColor.systemBlue.cgColor
        
        // Set content mode
        profileImageView.contentMode = .scaleAspectFill
    }
    
    @IBAction func changePhotoButtonTapped(_ sender: UIButton) {
        let actionSheet = UIAlertController(title: "Change Profile Photo",
                                          message: nil,
                                          preferredStyle: .actionSheet)
        
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            actionSheet.addAction(UIAlertAction(title: "Take Photo", style: .default) { [weak self] _ in
                self?.showImagePicker(sourceType: .camera)
            })
        }
        
        actionSheet.addAction(UIAlertAction(title: "Choose from Library", style: .default) { [weak self] _ in
            self?.showImagePicker(sourceType: .photoLibrary)
        })
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        
        present(actionSheet, animated: true)
    }
    
    private func showImagePicker(sourceType: UIImagePickerController.SourceType) {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = sourceType
        imagePicker.allowsEditing = true
        present(imagePicker, animated: true)
    }
    
    // MARK: - Image Picker Delegate Methods
    func imagePickerController(_ picker: UIImagePickerController,
                             didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let editedImage = info[.editedImage] as? UIImage {
            profileImageView.image = editedImage
            // Save the image
            if let imageData = editedImage.jpegData(compressionQuality: 0.8) {
                UserDefaults.standard.set(imageData, forKey: "profileImage")
            }
        }
        picker.dismiss(animated: true)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
    }
    
    // MARK: Setting Up UI
    private func setupUI() {
        // Make profile image circular
        profileImageView.layer.cornerRadius = profileImageView.frame.height / 2
        profileImageView.clipsToBounds = true
        profileImageView.contentMode = .scaleAspectFill
        
        // Setup segmented control
        segmentedControl.addTarget(self, action: #selector(segmentChanged), for: .valueChanged)
    }
    
    private func setupScrollView() {
        // Setup scroll view
        scrollView.showsVerticalScrollIndicator = false
        
        // Setup posts stack view
        postsStackView.axis = .vertical
        postsStackView.spacing = 16
        postsStackView.distribution = .fill
        
        // Setup groups stack view
        groupsStackView.axis = .vertical
        groupsStackView.spacing = 16
        groupsStackView.distribution = .fill
        
        // Initially hide groups stack view
        groupsStackView.isHidden = true
        
        // Make sure stack views are in scroll view
        postsStackView.translatesAutoresizingMaskIntoConstraints = false
        groupsStackView.translatesAutoresizingMaskIntoConstraints = false
        
        scrollView.addSubview(postsStackView)
        scrollView.addSubview(groupsStackView)
        
        // Simple constraints
        NSLayoutConstraint.activate([
            // Posts stack view constraints
            postsStackView.topAnchor.constraint(equalTo: scrollView.contentLayoutGuide.topAnchor),
            postsStackView.leadingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.leadingAnchor),
            postsStackView.trailingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.trailingAnchor),
            postsStackView.bottomAnchor.constraint(equalTo: scrollView.contentLayoutGuide.bottomAnchor),
            postsStackView.widthAnchor.constraint(equalTo: scrollView.frameLayoutGuide.widthAnchor),
            
            // Groups stack view constraints
            groupsStackView.topAnchor.constraint(equalTo: scrollView.contentLayoutGuide.topAnchor),
            groupsStackView.leadingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.leadingAnchor),
            groupsStackView.trailingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.trailingAnchor),
            groupsStackView.bottomAnchor.constraint(equalTo: scrollView.contentLayoutGuide.bottomAnchor),
            groupsStackView.widthAnchor.constraint(equalTo: scrollView.frameLayoutGuide.widthAnchor)
        ])
    }
    
    // MARK: GROUPS SETUP
    private func setupGroupsView() {
        scrollView.addSubview(groupsStackView)
        groupsStackView.isHidden = true
        
        NSLayoutConstraint.activate([
            groupsStackView.topAnchor.constraint(equalTo: scrollView.topAnchor, constant: 16),
            groupsStackView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor, constant: 16),
            groupsStackView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor, constant: -16),
            groupsStackView.widthAnchor.constraint(equalTo: scrollView.widthAnchor, constant: -32)
        ])
    }
    
    private func loadGroups() {
        groups = FlightGroup.sampleGroups()
        // MARK: DEBUG
        print("Loaded \(groups.count) groups")
        displayGroups()
    }
    
    private func displayGroups() {
        groupsStackView.arrangedSubviews.forEach { $0.removeFromSuperview() }
        
        for group in groups {
            // MARK: DEBUG
            print("Creating view for group: \(group.name)")
            let groupView = createGroupView(for: group)
            groupsStackView.addArrangedSubview(groupView)
        }
        // MARK: DEBUG: Update scroll view content size for groups
        let totalHeight = CGFloat(groups.count) * 100 // Assuming each group view is about 100 points tall
        scrollView.contentSize = CGSize(width: scrollView.frame.width, height: totalHeight)
    }
    
    private func createGroupView(for group: FlightGroup) -> UIView {
        let containerView = UIView()
        containerView.translatesAutoresizingMaskIntoConstraints = false
        containerView.backgroundColor = .secondarySystemBackground
        containerView.layer.cornerRadius = 12
        
        // Group Image
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = 25
        imageView.image = group.profileImage ?? UIImage(systemName: "airplane.circle.fill")
        
        // Group Name
        let nameLabel = UILabel()
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.text = group.name
        nameLabel.font = .systemFont(ofSize: 17, weight: .semibold)
        
        // Member Count
        let membersLabel = UILabel()
        membersLabel.translatesAutoresizingMaskIntoConstraints = false
        membersLabel.text = "\(group.memberCount) members"
        membersLabel.font = .systemFont(ofSize: 14)
        membersLabel.textColor = .secondaryLabel
        
        // Action Button
        var config = UIButton.Configuration.filled()
        config.contentInsets = NSDirectionalEdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16)
        config.baseBackgroundColor = group.groupType == .joinable ? .systemBlue : .tertiarySystemBackground
        config.baseForegroundColor = group.groupType == .joinable ? .white : .label
        config.title = group.groupType.buttonTitle
        config.cornerStyle = .medium
        
        let actionButton = UIButton(configuration: config)
        actionButton.translatesAutoresizingMaskIntoConstraints = false
        actionButton.addTarget(self, action: #selector(groupActionButtonTapped(_:)), for: .touchUpInside)
        actionButton.tag = groups.firstIndex(where: { $0.id == group.id }) ?? 0
        
        // Add subviews
        [imageView, nameLabel, membersLabel, actionButton].forEach { containerView.addSubview($0) }
        
        // Setup constraints
        NSLayoutConstraint.activate([
            containerView.heightAnchor.constraint(equalToConstant: 80),
            
            imageView.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 16),
            imageView.centerYAnchor.constraint(equalTo: containerView.centerYAnchor),
            imageView.widthAnchor.constraint(equalToConstant: 50),
            imageView.heightAnchor.constraint(equalToConstant: 50),
            
            nameLabel.leadingAnchor.constraint(equalTo: imageView.trailingAnchor, constant: 12),
            nameLabel.topAnchor.constraint(equalTo: imageView.topAnchor, constant: 4),
            
            membersLabel.leadingAnchor.constraint(equalTo: imageView.trailingAnchor, constant: 12),
            membersLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 4),
            
            actionButton.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -16),
            actionButton.centerYAnchor.constraint(equalTo: containerView.centerYAnchor)
        ])
        
        return containerView
    }
    
    @objc private func groupActionButtonTapped(_ sender: UIButton) {
        guard sender.tag < groups.count else { return }
        let group = groups[sender.tag]
        
        switch group.groupType {
        case .joinable:
            // Handle join action
            print("Joining group: \(group.name)")
        case .privategroup:
            // Show private group info
            print("Private group: \(group.name)")
        case .publicgroup:
            // Show public group info
            print("Public group: \(group.name)")
        }
    }
    
    // MARK: POSTS SETUP
    
    private func loadPosts() {
        posts = PilotPost.samplePosts()
        displayPosts()
    }
    
    private func displayPosts() {
        // Clear existing posts
        postsStackView.arrangedSubviews.forEach { $0.removeFromSuperview() }
        
        // Add each post
        for post in posts {
            let postView = createPostView(for: post)
            postsStackView.addArrangedSubview(postView)
            
            // Make each post view full screen height
            postView.heightAnchor.constraint(equalTo: scrollView.heightAnchor).isActive = true
            postView.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
            
            // Add this to enable scrolling:
            let totalHeight = scrollView.frame.height * CGFloat(posts.count)
            scrollView.contentSize = CGSize(width: scrollView.frame.width, height: totalHeight)
        }
    }
    
    private func createPostView(for post: PilotPost) -> UIView {
        let postView = UIView()
        //postView.backgroundColor = .systemBackground
        postView.backgroundColor = post.isAchievement ? .systemYellow.withAlphaComponent(0.1) : .systemBackground
        
        // Create post content
        let imageView = UIImageView()
        imageView.image = post.image
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        //imageView.image = post.image ?? UIImage(named: "post1")
        
        let titleLabel = UILabel()
        titleLabel.text = post.title
        titleLabel.font = .systemFont(ofSize: 18, weight: .bold)
        
        let descLabel = UILabel()
        descLabel.text = post.description
        descLabel.numberOfLines = 0
        
        let timeLabel = UILabel()
        let formatter = RelativeDateTimeFormatter()
        timeLabel.text = formatter.localizedString(for: post.timestamp, relativeTo: Date())
        timeLabel.textColor = .secondaryLabel
        
        // Add subviews
        [imageView, titleLabel, descLabel, timeLabel].forEach {
            $0.translatesAutoresizingMaskIntoConstraints = false
            postView.addSubview($0)
        }
        
        // Setup constraints
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: postView.topAnchor, constant: 16),
            imageView.leadingAnchor.constraint(equalTo: postView.leadingAnchor, constant: 16),
            imageView.trailingAnchor.constraint(equalTo: postView.trailingAnchor, constant: -16),
            imageView.heightAnchor.constraint(equalTo: postView.heightAnchor, multiplier: 0.6),
            
            titleLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 16),
            titleLabel.leadingAnchor.constraint(equalTo: postView.leadingAnchor, constant: 16),
            titleLabel.trailingAnchor.constraint(equalTo: postView.trailingAnchor, constant: -16),
            
            descLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 8),
            descLabel.leadingAnchor.constraint(equalTo: postView.leadingAnchor, constant: 16),
            descLabel.trailingAnchor.constraint(equalTo: postView.trailingAnchor, constant: -16),
            
            timeLabel.topAnchor.constraint(equalTo: descLabel.bottomAnchor, constant: 8),
            timeLabel.leadingAnchor.constraint(equalTo: postView.leadingAnchor, constant: 16),
            timeLabel.trailingAnchor.constraint(equalTo: postView.trailingAnchor, constant: -16)
        ])
        
        return postView
    }
    
    // MARK: Segment Change
    @IBAction func segmentChanged(_ sender: UISegmentedControl) {
        print("Segment changed to: \(sender.selectedSegmentIndex)")
        // Handle segment changes here
        switch sender.selectedSegmentIndex {
        case 0:
            postsStackView.isHidden = false
            groupsStackView.isHidden = true
            // Update scroll view for posts
            let postsHeight = scrollView.frame.height * CGFloat(posts.count)
            scrollView.contentSize = CGSize(width: scrollView.frame.width, height: postsHeight)
        case 1:
            postsStackView.isHidden = true
            groupsStackView.isHidden = false
            // Update scroll view for groups
            let groupsHeight = CGFloat(groups.count) * 100 // Assuming each group view is about 100 points tall
            scrollView.contentSize = CGSize(width: scrollView.frame.width, height: groupsHeight)
        default:
            break
        }
    }
}

import UIKit

struct PilotPost {
    let id: String
    let image: UIImage?
    let title: String
    let description: String
    let timestamp: Date
    let isAchievement: Bool
    
    // Sample data
    static func samplePosts() -> [PilotPost] {
        return [
            PilotPost(
                id: "1",
                image: UIImage(named: "post1"),
                title: "Sunday Flight ✈️",
                description: "Capturing the serene beauty of the horizon from my recent flight...",
                timestamp: Date(),
                isAchievement: false
            ),
            PilotPost(
                id: "2",
                image: nil,
                title: "First Solo Flight!",
                description: "Achievement unlocked: Completed my first solo flight!",
                timestamp: Date().addingTimeInterval(-86400), // yesterday
                isAchievement: true
            ),
            PilotPost(
                id: "3",
                image: UIImage(named: "post1"),
                title: "Sunset Landing 🌅",
                description: "Perfect evening for flying. Smooth landing at SFO.",
                timestamp: Date().addingTimeInterval(-172800), // 2 days ago
                isAchievement: false
            )
        ]
    }
}

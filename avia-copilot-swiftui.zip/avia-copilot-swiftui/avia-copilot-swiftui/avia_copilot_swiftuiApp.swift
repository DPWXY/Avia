//
//  avia_copilot_swiftuiApp.swift
//  avia-copilot-swiftui
//
//  Created by Rana Taki on 2/17/25.
//

import SwiftUI

@main
struct avia_copilot_swiftuiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

import SwiftUI

struct GroupMember: Identifiable {
    let id = UUID()
    var name: String
    var profileImage: UIImage?
}

struct Group: Identifiable {
    let id = UUID()
    var name: String
    var profileImage: UIImage?
    var members: [GroupMember]
    
    var memberSummary: String {
        if members.isEmpty {
            return "No members"
        }
        
        let displayedMembers = members.prefix(2)
        let remainingCount = members.count - displayedMembers.count
        
        var summary = displayedMembers.map { $0.name }.joined(separator: ", ")
        if remainingCount > 0 {
            summary += " ... \(remainingCount) other member"
            if remainingCount > 1 {
                summary += "s"
            }
        }
        
        return summary
    }
}

struct GroupView: View {
    let group: Group
    
    var body: some View {
        HStack(spacing: 16) {
            // Group profile image
            if let profileImage = group.profileImage {
                Image(uiImage: profileImage)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 60, height: 60)
                    .clipShape(Circle())
            } else {
                Image(systemName: "person.3.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 60, height: 60)
                    .foregroundColor(.white.opacity(0.8))
            }
            
            // Group info
            VStack(alignment: .leading, spacing: 4) {
                Text(group.name)
                    .font(.headline)
                    .foregroundColor(.white)
                
                Text(group.memberSummary)
                    .font(.subheadline)
                    .foregroundColor(.white.opacity(0.7))
                    .lineLimit(1)
            }
            
            Spacer()
            
            // Join status indicator
            Image(systemName: "checkmark.circle.fill")
                .foregroundColor(.green)
                .font(.system(size: 24))
        }
        .padding()
        .background(Color.white.opacity(0.1))
        .cornerRadius(16)
    }
}


import SwiftUI

class CreatePostViewModel: ObservableObject {
    @Published var title = ""
    @Published var content = ""
    @Published var selectedImage: UIImage?
    @Published var showingImagePicker = false
    
    func createPost() -> Post {
        let currentDate = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd"
        
        return Post(
            author: PostAuthor(
                name: "Rana Taki",
                handle: "ranataki13",
                profileImage: nil
            ),
            title: title,
            date: dateFormatter.string(from: currentDate),
            content: content,
            image: selectedImage
        )
    }
}

struct CreatePostView: View {
    @Binding var selectedTab: Int
    @Binding var posts: [Post]
    @StateObject private var viewModel = CreatePostViewModel()
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Button(action: {
                    selectedTab = 0  // Go back to feed
                }) {
                    Image(systemName: "xmark")
                        .font(.title2)
                        .foregroundColor(.white)
                }
                
                Spacer()
                
                Button(action: {
                    // Create and add post
                    let newPost = viewModel.createPost()
                    posts.insert(newPost, at: 0)
                    selectedTab = 0  // Go back to feed
                }) {
                    Text("Post")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 8)
                        .background(
                            (!viewModel.title.isEmpty && !viewModel.content.isEmpty) ?
                                Color.blue : Color.blue.opacity(0.5)
                        )
                        .cornerRadius(20)
                }
                .disabled(viewModel.title.isEmpty || viewModel.content.isEmpty)
            }
            .padding()
            .background(Color.black.opacity(0.3))
            
            // Body
            ScrollView {
                VStack(spacing: 16) {
                    // Title
                    TextField("Title", text: $viewModel.title)
                        .font(.title3)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.white.opacity(0.1))
                        .cornerRadius(12)
                        .padding(.horizontal)
                    
                    // Content
                    TextField("What's happening in the sky?", text: $viewModel.content, axis: .vertical)
                        .lineLimit(5...10)
                        .font(.body)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.white.opacity(0.1))
                        .cornerRadius(12)
                        .padding(.horizontal)
                    
                    // Image Selection
                    VStack {
                        if let image = viewModel.selectedImage {
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFit()
                                .frame(maxHeight: 300)
                                .cornerRadius(12)
                                .overlay(
                                    Button(action: {
                                        viewModel.selectedImage = nil
                                    }) {
                                        Image(systemName: "xmark.circle.fill")
                                            .font(.title)
                                            .foregroundColor(.white)
                                            .background(Color.black.opacity(0.5))
                                            .clipShape(Circle())
                                    }
                                    .padding(8),
                                    alignment: .topTrailing
                                )
                        }
                        
                        Button(action: {
                            viewModel.showingImagePicker = true
                        }) {
                            HStack {
                                Image(systemName: "photo")
                                    .font(.title2)
                                Text("Add Photo")
                                    .font(.headline)
                            }
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.white.opacity(0.1))
                            .cornerRadius(12)
                        }
                    }
                    .padding(.horizontal)
                }
                .padding(.vertical)
            }
        }
        .background(
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 0.443, green: 0.816, blue: 0.816),  // Teal
                    Color(red: 0.2, green: 0.4, blue: 0.6),        // Mid blue
                    Color(red: 0.051, green: 0.043, blue: 0.267)   // Navy blue
                ]),
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
        )
        .sheet(isPresented: $viewModel.showingImagePicker) {
            ImagePicker(selectedImage: $viewModel.selectedImage)
        }
    }
}

#Preview {
    CreatePostView(selectedTab: .constant(3), posts: .constant([]))
        .preferredColorScheme(.dark)
}


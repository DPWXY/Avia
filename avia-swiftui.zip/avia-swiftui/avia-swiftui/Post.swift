import SwiftUI

struct PostAuthor: Identifiable {
    let id = UUID()
    var name: String
    var handle: String
    var profileImage: UIImage?
}

struct Post: Identifiable {
    let id = UUID()
    var author: PostAuthor
    var title: String
    var date: String
    var content: String
    private var uiImage: UIImage?
    var image: Image? {
        if let uiImage = uiImage {
            return Image(uiImage: uiImage)
        }
        return nil
    }
    
    init(author: PostAuthor, title: String, date: String, content: String, image: UIImage? = nil) {
        self.author = author
        self.title = title
        self.date = date
        self.content = content
        self.uiImage = image
    }
}

struct PostView: View {
    let post: Post
    let isProfileView: Bool
    
    init(post: Post, isProfileView: Bool = false) {
        self.post = post
        self.isProfileView = isProfileView
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Date and Title
            VStack(alignment: .leading, spacing: 8) {
                if !isProfileView {
                    // Author header for feed view
                    HStack(spacing: 12) {
                        if let profileImage = post.author.profileImage {
                            Image(uiImage: profileImage)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 40, height: 40)
                                .clipShape(Circle())
                        } else {
                            Image(systemName: "person.circle.fill")
                                .resizable()
                                .frame(width: 40, height: 40)
                                .foregroundColor(.white.opacity(0.8))
                        }
                        
                        VStack(alignment: .leading, spacing: 2) {
                            Text(post.author.name)
                                .font(.headline)
                                .foregroundColor(.white)
                            
                            Text("@\(post.author.handle)")
                                .font(.subheadline)
                                .foregroundColor(.white.opacity(0.7))
                        }
                        
                        Spacer()
                        
                        Text(post.date)
                            .font(.caption)
                            .foregroundColor(.white.opacity(0.7))
                    }
                } else {
                    // Simple header for profile view
                    HStack {
                        Text(post.date)
                            .font(.caption)
                            .foregroundColor(.white.opacity(0.7))
                        Spacer()
                    }
                }
                
                Text(post.title)
                    .font(.headline)
                    .foregroundColor(.white)
            }
            
            // Content
            Text(post.content)
                .font(.body)
                .foregroundColor(.white)
            
            if let image = post.image {
                image
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(12)
            }
            
            // Action buttons
            HStack(spacing: 20) {
                Button(action: {}) {
                    Image(systemName: "heart")
                        .foregroundColor(.white)
                }
                
                Button(action: {}) {
                    Image(systemName: "bubble.right")
                        .foregroundColor(.white)
                }
                
                Button(action: {}) {
                    Image(systemName: "arrowshape.turn.up.right")
                        .foregroundColor(.white)
                }
            }
        }
        .padding()
        .background(Color.white.opacity(0.1))
        .cornerRadius(16)
        .cornerRadius(16)

    }
}

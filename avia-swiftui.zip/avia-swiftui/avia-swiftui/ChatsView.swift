import SwiftUI

enum ChatType {
    case direct
    case group
}

struct Chat: Identifiable {
    let id = UUID()
    var name: String
    var lastMessage: String
    var timestamp: String
    var unreadCount: Int
    var type: ChatType
    var profileImage: UIImage?
}

class ChatsViewModel: ObservableObject {
    @Published var chats: [Chat] = [
        // Group chats
        Chat(
            name: "PPL Study Group",
            lastMessage: "Alex: Anyone up for a study session tonight?",
            timestamp: "2:30 PM",
            unreadCount: 3,
            type: .group,
            profileImage: nil
        ),
        Chat(
            name: "Bay Area Pilots",
            lastMessage: "Sarah: Weather's looking great for the weekend!",
            timestamp: "11:45 AM",
            unreadCount: 0,
            type: .group,
            profileImage: nil
        ),
        
        // Direct messages
        Chat(
            name: "John Smith",
            lastMessage: "Thanks for the flight tips!",
            timestamp: "Yesterday",
            unreadCount: 0,
            type: .direct,
            profileImage: nil
        ),
        Chat(
            name: "Sarah Chen",
            lastMessage: "Let's plan that cross country soon",
            timestamp: "Yesterday",
            unreadCount: 2,
            type: .direct,
            profileImage: nil
        )
    ]
}

struct ChatRow: View {
    let chat: Chat
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
        HStack(spacing: 16) {
            // Profile image
            if let profileImage = chat.profileImage {
                Image(uiImage: profileImage)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 50, height: 50)
                    .clipShape(Circle())
            } else {
                Image(systemName: chat.type == .group ? "person.3.fill" : "person.circle.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 50, height: 50)
                    .foregroundColor(.white.opacity(0.8))
            }
            
            // Chat info
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(chat.name)
                        .font(.headline)
                        .foregroundColor(.white)
                    
                    Spacer()
                    
                    Text(chat.timestamp)
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
                
                HStack {
                    Text(chat.lastMessage)
                        .font(.subheadline)
                        .foregroundColor(.gray)
                        .lineLimit(1)
                    
                    Spacer()
                    
                    if chat.unreadCount > 0 {
                        Text("\(chat.unreadCount)")
                            .font(.caption)
                            .foregroundColor(.white)
                            .padding(6)
                            .background(Color.blue)
                            .clipShape(Circle())
                    }
                }
            }
        }
        .padding()
        .background(Color.white.opacity(0.1))
        .cornerRadius(16)
        }
    }
}

struct ChatsView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var searchText = ""
    @StateObject private var viewModel = ChatsViewModel()
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color(red: 0.443, green: 0.816, blue: 0.816),  // Teal
                        Color(red: 0.2, green: 0.4, blue: 0.6),        // Mid blue
                        Color(red: 0.051, green: 0.043, blue: 0.267)   // Navy blue
                    ]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()
                
                VStack(spacing: 0) {
                    // Header
                    HStack {
                        Button(action: {
                            dismiss()
                        }) {
                            Image(systemName: "chevron.left")
                                .font(.title2)
                                .foregroundColor(.white)
                        }
                        
                        Spacer()
                        
                        Text("Chats")
                            .font(.title3)
                            .fontWeight(.semibold)
                            .foregroundColor(.white)
                        
                        Spacer()
                        
                        Button(action: {
                            // New chat action
                        }) {
                            Image(systemName: "square.and.pencil")
                                .font(.title2)
                                .foregroundColor(.white)
                        }
                    }
                    .padding()
                    .background(Color.black.opacity(0.3))
                    
                    // Search bar
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.gray)
                        
                        TextField("Search", text: .constant(""))
                            .textFieldStyle(.plain)
                    }
                    .padding()
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(12)
                    .padding()
                    
                    // Chat list
                    ScrollView {
                        LazyVStack(spacing: 16) {
                            // Group chats section
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Groups")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .padding(.horizontal)
                                
                                ForEach(viewModel.chats.filter { $0.type == .group }) { chat in
                                    ChatRow(chat: chat) {
                                        // TODO: Add chat action here
                                    }
                                    .padding(.horizontal)
                                }
                            }
                            
                            // Direct messages section
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Direct Messages")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .padding(.horizontal)
                                
                                ForEach(viewModel.chats.filter { $0.type == .direct }) { chat in
                                    ChatRow(chat: chat) {
                                        // TODO: Add chat action here
                                    }
                                    .padding(.horizontal)
                                }
                            }
                        }
                        .padding(.vertical)
                    }
                }
                .navigationBarHidden(true)
            }
        }
    }
}

#Preview {
    ChatsView()
        .preferredColorScheme(.dark)
}

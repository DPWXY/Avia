import SwiftUI

struct AviaView: View {
    @State private var selectedTab = 0
    @State private var posts: [Post] = [
        Post(
            author: PostAuthor(
                name: "Rana Taki",
                handle: "ranataki13",
                profileImage: nil
            ),
            title: "Sunday flight",
            date: "02/20",
            content: "Short sunday flight over KPAO ✈️",
            image: nil
        ),
        Post(
            author: PostAuthor(
                name: "Rana Taki",
                handle: "ranataki13",
                profileImage: nil
            ),
            title: "Solo Endorsement",
            date: "02/17",
            content: "Achieved my solo endorsement today! 🎉",
            image: nil
        )
    ]
    
    @StateObject private var profile = PilotProfile(
        name: "Rana Taki",
        handle: "ranataki13",
        rank: "Student Pilot",
        hoursFlown: 60,
        followers: 100,
        groups: 10
    )
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 0.443, green: 0.816, blue: 0.816),
                    Color(red: 0, green: 0.29, blue: 0.561),
                    Color(red: 0.051, green: 0.043, blue: 0.267)
                ]),
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            
            VStack(spacing: 0) {
                if selectedTab == 0 {
                    FeedView(personalPosts: $posts)
                } else if selectedTab == 4 {
                    VStack(spacing: 0) {
                        // Header
                        ProfileHeaderView(profile: profile)
                        
                        // Body
                        ScrollView {
                            VStack(spacing: 16) {
                                ForEach(posts) { post in
                                    PostView(post: post, isProfileView: true)
                                        .padding(.horizontal)
                                }
                            }
                            .padding(.vertical)
                        }
                        .background(Color.clear)
                    }
                } else if selectedTab == 2 {
                    AviaCopilotView(selectedTab: $selectedTab)
                } else if selectedTab == 1 {
                    GroupsView()
                } else if selectedTab == 3 {
                    CreatePostView(selectedTab: $selectedTab, posts: $posts)
                } else {
                    Spacer()
                    Text("Coming soon!")
                        .foregroundColor(.white)
                    Spacer()
                }
                
                // Footer
                HStack(spacing: 0) {
                    ForEach(0..<5) { index in
                        Button(action: {
                            withAnimation {
                                selectedTab = index
                            }
                        }) {
                            VStack {
                                Image(systemName: footerIcon(for: index))
                                    .font(.system(size: 24))
                                    .foregroundColor(selectedTab == index ? .white : .white.opacity(0.6))
                            }
                        }
                        .frame(maxWidth: .infinity)
                    }
                }
                .padding(.vertical, 8)
                .background(Color.black.opacity(0.3))
            }
        }
    }
    
    private func footerIcon(for index: Int) -> String {
        switch index {
        case 0: return "house.fill"
        case 1: return "person.2.fill"
        case 2: return "mic.circle.fill"
        case 3: return "plus.app.fill"
        case 4: return "person.crop.circle.fill"
        default: return ""
        }
    }
}

struct AviaView_Previews: PreviewProvider {
    static var previews: some View {
        AviaView()
    }
}



import SwiftUI

class PilotProfile: Identifiable, ObservableObject {
    let id = UUID()
    @Published var name: String
    @Published var handle: String
    @Published var rank: String
    @Published var hoursFlown: Int
    @Published var followers: Int
    @Published var groups: Int
    @Published var profileImage: UIImage?
    
    init(name: String, handle: String, rank: String, hoursFlown: Int, followers: Int, groups: Int, profileImage: UIImage? = nil) {
        self.name = name
        self.handle = handle
        self.rank = rank
        self.hoursFlown = hoursFlown
        self.followers = followers
        self.groups = groups
        self.profileImage = profileImage
    }
}

enum SheetType: Identifiable {
    case imagePicker
    case chats
    
    var id: Int {
        switch self {
        case .imagePicker: return 0
        case .chats: return 1
        }
    }
}

struct ProfileHeaderView: View {
    @ObservedObject var profile: PilotProfile
    @State private var selectedImage: UIImage?
    @State private var activeSheet: SheetType?
    
    var body: some View {
        VStack(spacing: 16) {
            // Top buttons
            HStack {
                Button(action: {}) {
                    Image(systemName: "gear")
                        .foregroundColor(.white)
                }
                
                Spacer()
                
                Button(action: {
                    activeSheet = .chats
                }) {
                    Image(systemName: "message")
                        .foregroundColor(.white)
                }
            }
            .padding(.horizontal)
            
            // Profile section
            VStack(spacing: 8) {
                Button(action: { activeSheet = .imagePicker }) {
                    if let profileImage = profile.profileImage {
                        Image(uiImage: profileImage)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 100, height: 100)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.white, lineWidth: 2))
                    } else {
                        Image(systemName: "person.circle.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                            .foregroundColor(.white)
                    }
                }
                .overlay(alignment: .bottomTrailing) {
                    Image(systemName: "camera.circle.fill")
                        .foregroundColor(.white)
                        .font(.system(size: 24))
                        .background(Color.blue)
                        .clipShape(Circle())
                        .offset(x: 5, y: 5)
                }
                
                Text(profile.name)
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                
                Text("@\(profile.handle)")
                    .font(.subheadline)
                    .foregroundColor(.white.opacity(0.8))
                
                Text(profile.rank)
                    .font(.subheadline)
                    .foregroundColor(.white.opacity(0.9))
            }
            
            // Stats section
            HStack(spacing: 30) {
                VStack {
                    Text("\(profile.hoursFlown)")
                        .font(.headline)
                        .foregroundColor(.white)
                    Text("Hours")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.8))
                }
                
                VStack {
                    Text("\(profile.followers)")
                        .font(.headline)
                        .foregroundColor(.white)
                    Text("Followers")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.8))
                }
                
                VStack {
                    Text("\(profile.groups)")
                        .font(.headline)
                        .foregroundColor(.white)
                    Text("Groups")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.8))
                }
            }
        }
        .padding()
        .sheet(item: $activeSheet) { type in
            switch type {
            case .imagePicker:
                ImagePicker(selectedImage: Binding(
                    get: { selectedImage },
                    set: { newImage in
                        selectedImage = newImage
                        if let newImage = newImage {
                            profile.profileImage = newImage
                        }
                    }
                ))
            case .chats:
                ChatsView()
            }
        }
    }
}

//
//  avia_swiftuiApp.swift
//  avia-swiftui
//
//  Created by Rana Taki on 2/24/25.
//

import SwiftUI

@main
struct avia_swiftuiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

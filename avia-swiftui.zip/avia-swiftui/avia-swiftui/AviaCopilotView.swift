import SwiftUI
import AVFoundation

class ChatViewModel: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var isRecording = false
    @Published var inputText = ""
    
    private let speechSynthesizer = AVSpeechSynthesizer()
    
    func sendMessage(_ content: String, sender: MessageSender = .user) {
        let message = ChatMessage(content: content, sender: sender, timestamp: Date())
        messages.append(message)
        
        if sender == .user {
            // Simulate LLM response
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                self.respondToMessage(content)
            }
        }
    }
    
    private func respondToMessage(_ userMessage: String) {
        let response = "This is a simulated response to: \(userMessage)"
        let message = ChatMessage(content: response, sender: .assistant, timestamp: Date())
        messages.append(message)
        
        // Speak the response
        let utterance = AVSpeechUtterance(string: response)
        utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        utterance.rate = 0.5
        speechSynthesizer.speak(utterance)
    }
    
    func toggleRecording() {
        isRecording.toggle()
        // TODO: Implement actual voice recording
    }
}

struct AviaCopilotView: View {
    @Binding var selectedTab: Int
    @FocusState private var isInputFocused: Bool
    @StateObject private var viewModel = ChatViewModel()
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            VStack(spacing: 8) {
                HStack {
                    Button(action: {
                        selectedTab = 0  // Go back to feed (home tab)
                    }) {
                        Image(systemName: "arrow.left")
                            .font(.title3)
                            .foregroundColor(.white)
                    }
                    
                    Spacer()
                    
                    Text("Avia Copilot")
                        .font(.title3)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                    
                    Spacer()
                    
                    // Placeholder to maintain centered title
                    Color.clear
                        .frame(width: 24, height: 24)
                }
                
                Text("Push the record button or text for help")
                    .font(.subheadline)
                    .foregroundColor(.white.opacity(0.8))
            }
            .padding()
            .background(Color.blue.opacity(0.2))
            
            // Body
            VStack(spacing: 0) {
                // Microphone Button
                VStack {
                    Button(action: { viewModel.toggleRecording() }) {
                        ZStack {
                            Circle()
                                .fill(
                                    RadialGradient(
                                        gradient: Gradient(colors: [
                                            Color(red: 0.051, green: 0.043, blue: 0.267),
                                            Color(red: 0.1, green: 0.15, blue: 0.35)
                                        ]),
                                        center: .center,
                                        startRadius: 0,
                                        endRadius: 60
                                    )
                                )
                                .frame(width: 130, height: 130)
                            
                            // Outer glow when recording
                            if viewModel.isRecording {
                                Circle()
                                    .fill(
                                        RadialGradient(
                                            gradient: Gradient(colors: [
                                                Color.blue.opacity(0.3),
                                                Color.blue.opacity(0)
                                            ]),
                                            center: .center,
                                            startRadius: 40,
                                            endRadius: 80
                                        )
                                    )
                                    .frame(width: 160, height: 160)
                                    .animation(.easeInOut(duration: 1).repeatForever(autoreverses: true), value: viewModel.isRecording)
                            }
                            
                            Image(systemName: "mic.fill")
                                .font(.system(size: 50))
                                .foregroundColor(.white)
                                .scaleEffect(viewModel.isRecording ? 1.2 : 1.0)
                        }
                        .animation(.spring(response: 0.3), value: viewModel.isRecording)
                    }
                }
                .frame(height: 200)
                
                // Chat Messages
                ScrollView {
                    LazyVStack {
                        ForEach(viewModel.messages) { message in
                            ChatBubble(message: message)
                        }
                    }
                    .padding(.vertical)
                }
            }
            
            // Footer
            HStack(spacing: 12) {
                TextField("Write your message", text: $viewModel.inputText)
                    .textFieldStyle(.plain)
                    .padding(12)
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(20)
                    .foregroundColor(.white)
                    .tint(.white)
                    .submitLabel(.send)
                    .focused($isInputFocused)
                    .onSubmit {
                        if !viewModel.inputText.isEmpty {
                            viewModel.sendMessage(viewModel.inputText)
                            viewModel.inputText = ""
                        }
                    }
                
                Button(action: {
                    guard !viewModel.inputText.isEmpty else { return }
                    viewModel.sendMessage(viewModel.inputText)
                    viewModel.inputText = ""
                }) {
                    Image(systemName: "paperplane.fill")
                        .font(.system(size: 20))
                        .foregroundColor(.white)
                        .frame(width: 44, height: 44)
                        .background(Color(red: 0.051, green: 0.043, blue: 0.267))
                        .clipShape(Circle())
                }
            }
            .padding()
            .background(Color.black.opacity(0.3))
        }
        .background(
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 0.443, green: 0.816, blue: 0.816),  // Teal
                    Color(red: 0.2, green: 0.4, blue: 0.6),        // Mid blue
                    Color(red: 0.051, green: 0.043, blue: 0.267)   // Navy blue
                ]),
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
        )
    }
}

#Preview {
    AviaCopilotView(selectedTab: .constant(2))
        .preferredColorScheme(.dark)
}




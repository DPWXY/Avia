import SwiftUI

class FeedViewModel: ObservableObject {
    @Published var feedPosts: [Post] = [
        Post(
            author: PostAuthor(
                name: "John Smith",
                handle: "flyingj",
                profileImage: nil
            ),
            title: "First Solo Cross Country",
            date: "02/24",
            content: "Just completed my first solo cross country flight! 🛩️ Beautiful views and perfect weather.",
            image: nil
        ),
        Post(
            author: PostAuthor(
                name: "Sarah Chen",
                handle: "sarahpilot",
                profileImage: nil
            ),
            title: "Night Rating Complete",
            date: "02/23",
            content: "Finally got my night rating! The city lights were amazing ✨",
            image: nil
        )
    ]
}

struct FeedView: View {
    @StateObject private var viewModel = FeedViewModel()
    @Binding var personalPosts: [Post]
    @State private var showingChats = false
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Button(action: {}) {
                    Image(systemName: "gear")
                        .font(.title2)
                        .foregroundColor(.white)
                }
                
                Spacer()
                
                Text("Feed")
                    .font(.title3)
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                
                Spacer()
                
                Button(action: {
                    showingChats = true
                }) {
                    Image(systemName: "message")
                        .font(.title2)
                        .foregroundColor(.white)
                }
            }
            .padding()
            .background(
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color(red: 0.443, green: 0.816, blue: 0.816),  // Teal
                        Color(red: 0.2, green: 0.4, blue: 0.6),        // Mid blue
                        Color(red: 0.051, green: 0.043, blue: 0.267)   // Navy blue
                    ]),
                    startPoint: .top,
                    endPoint: .bottom
                )
            )
            
            // Body
            ScrollView {
                LazyVStack(spacing: 16) {
                    // Personal posts at the top
                    ForEach(personalPosts) { post in
                        PostView(post: post)
                            .padding(.horizontal)
                    }
                    
                    // Feed posts from friends
                    ForEach(viewModel.feedPosts) { post in
                        PostView(post: post)
                            .padding(.horizontal)
                    }
                }
                .padding(.vertical)
            }

        }
        .background(
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 0.443, green: 0.816, blue: 0.816),  // Teal
                    Color(red: 0.2, green: 0.4, blue: 0.6),        // Mid blue
                    Color(red: 0.051, green: 0.043, blue: 0.267)   // Navy blue
                ]),
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
        )
        .sheet(isPresented: $showingChats) {
            ChatsView()
        }
    }

}

#Preview {
    FeedView(personalPosts: .constant([
        Post(
            author: PostAuthor(
                name: "John Smith",
                handle: "flyingj",
                profileImage: nil
            ),
            title: "First Solo Cross Country",
            date: "02/24",
            content: "Just completed my first solo cross country flight! 🛩️ Beautiful views and perfect weather.",
            image: nil
        ),
        Post(
            author: PostAuthor(
                name: "Sarah Chen",
                handle: "sarahpilot",
                profileImage: nil
            ),
            title: "Night Rating Complete",
            date: "02/23",
            content: "Finally got my night rating! The city lights were amazing ✨",
            image: nil
        )
    ]))
    .preferredColorScheme(.dark)
}

